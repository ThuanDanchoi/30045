
    function barChart() {
        var svg = d3.select("#chart")
            .append("svg")
            .attr("width", w)
            .attr("height", h);

        svg.selectAll("rect")
            .data(wombatSightings)
            .enter()
            .append("rect")
            .attr("x", function(d, i) {
                return i * (w / wombatSightings.length);
            })
            .attr("y", function(d) {
                return h - (d.wombats * 4);
            })
            .attr("width", w / wombatSightings.length - barpadding)
            .attr("height", function(d) {
                return d.wombats * 4;
            })
            .attr("fill", function(d) {
                return "rgb(0, " + Math.round(d.wombats * 10) + ", " + Math.round(d.wombats * 5) + ")";
            });
    }


window.onload = barChart();
